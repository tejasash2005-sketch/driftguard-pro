# DriftGuard Pro 1.1.2 — final verification sprint

Date: 2026-10-27. This report records the latest verification attempt and supersedes older
environment notes in `FINAL_QUALITY_AUDIT.md` where they differ.

## Environment and CI availability

- Supported runtime found: Python 3.12.15 at `C:\Users\Shridevi S Madiwalar\.local\bin\python3.12.exe`.
- A clean `.venv-verify` was created with Python 3.12. It initially had no project/runtime/dev
  dependencies. `pydantic`, `jsonschema`, `fastapi`, `pytest`, `pytest-cov`, `hypothesis`, `ruff`,
  and `mypy` are absent from that environment.
- In the command table, `python3.12` means the full executable path listed above.
- `python -m pip install -e '.[dev]'` was attempted twice and remained at isolated build dependency
  installation without returning. Both processes were manually interrupted; **no exit code was
  returned**. Previous package-index attempts in this environment reported blocked network access.
- GitHub Actions could not be dispatched: `gh auth status` exited 1 because the saved GitHub token
  is invalid. The supplied project has no Git repository/remote. There is no available free remote
  CI route from this checkout.

## Root-cause diagnosis

The dependency groups are not missing declarations. `pyproject.toml` declares Pydantic, jsonschema,
FastAPI, and Uvicorn as required runtime dependencies and pytest, pytest-cov, Hypothesis, HTTPX,
Ruff, mypy, and types-jsonschema in the `dev` extra. The documented command requests that extra.
The clean venv remained empty because pip did not finish isolated build-dependency installation
(`setuptools>=77` and `wheel`); consequently pip never got to install the project or its runtime/dev
dependencies. The Python 3.12 pip cache reports no locally built wheels. The earlier environment
also reported network denial when accessing the package index. This is an installation environment
blocker, not evidence that the source imports are undeclared. No dependency-group change can make a
fresh online install succeed while the package index is inaccessible; no local wheelhouse was
available to use legitimately.

## Commands and results

| Command/check | Result |
|---|---|
| Python 3.12.15 interpreter startup | **PASS**, version reported |
| `python3.12 -m compileall -q src tests benchmarks scripts` | **PASS**, exit 0; syntax check only |
| Source/ZIP byte comparison before this report/workflow edit | **PASS**, 71 source files, 0 missing and 0 mismatched entries; ZIP rebuilt and rechecked after edits |
| `python3.12 scripts/regression_gate_demo.py` | **BLOCKED**, exit 1 before evaluation: missing `pydantic` |
| `python3.12 -m pytest -q --cov` in clean venv | **BLOCKED**, exit 1: `pytest` is not installed; 0 tests collected |
| `python3.12 -m ruff check .` | **BLOCKED**, exit 1: `ruff` is not installed |
| `python3.12 -m ruff format --check .` | **BLOCKED**, exit 1: `ruff` is not installed |
| `python3.12 -m mypy` | **BLOCKED**, exit 1: `mypy` is not installed |
| `python3.12 benchmarks/benchmark_core.py` | **BLOCKED**, exit 1: package is not installed/importable |
| Benchmark with `PYTHONPATH=src` | **BLOCKED**, exit 1: missing `jsonschema` |
| CLI help and example smoke outside the repository from installed wheel | **BLOCKED**, both exit 1: missing runtime dependency `pydantic` |
| Offline gate positive/negative verdicts and report assertions | **NOT VERIFIED**; demo stopped before generating reports |
| API/auth/SQLite/dashboard tests | **NOT RUN**; required runtime/dev dependencies are missing |
| `docker info` | **BLOCKED**, exit 1: Docker daemon pipe is unavailable |
| `gh auth status` | **BLOCKED**, exit 1: saved token is invalid; no remote workflow was run |
| `pip-audit` against project dependencies | **NOT RUN**: the project declares open version ranges rather than a pinned lock; the audit service/package index is unavailable. A successful vulnerability/license audit is not claimed. |
| Benchmark timing and memory | **NOT MEASURED**; execution stopped at missing dependencies |

The project wheel was installed into the clean Python 3.12 venv with
`python -m pip install --no-index --no-deps .build-check/driftguard_pro-1.1.2-py3-none-any.whl`:
**PASS, exit 0**. This verifies wheel installation only, without dependencies. `importlib.resources`
checks for version 1.1.2, the bundled dashboard index, and the bundled demo example all **passed**.
The outside-repository CLI checks then failed as above, so this is not a successful application
installation test.

The wheel and sdist were rebuilt using the installed setuptools backend under Python 3.10 after the
verification report and workflow edits; package contents and `Requires-Python: >=3.11` were
inspected. The current project ZIP was rebuilt after the latest source/workflow/report edits and
passed ZIP opening, required-file, no-cache/no-database/no-secret checks.

The provider mock subset had previously reported 11 passing tests under Python 3.10 with an
in-process `StrEnum` shim. That historical result is not a supported-runtime test result and does
not substitute for the full suite.

Static CI review: the PowerShell smoke step checks each command's `$LASTEXITCODE` immediately,
including the expected regression exit 1. The offline demo is a separate CI command whose nonzero
Python process exit fails the step. The CI workflow itself was not executed in this sprint.

## Free-only operation

The core has no credentials or paid-service requirement by design. The checked-in regression demo
uses synthetic JSON cases and the required CLI/assertion/statistics logic, not provider SDKs. Optional
provider recording is the only documented path that sends prompts to an external provider and may
incur cost. Functional execution of local API, SQLite, report generation, and the offline demo was
not verified in this sprint because the required open-source Python packages could not be installed.
Initial installation requires downloading the declared packages from a package index; no paid
service is required, but network access or a pre-populated wheelhouse is required.

## Result and remaining blockers

The latest ZIP is structurally valid and matches the latest included files. Python 3.12 syntax and
wheel metadata/package-data installation are verified. **No supported-runtime test suite, coverage
percentage, Ruff result, mypy result, working CLI/API run, passing/failing gate execution, security
audit, or performance measurement was obtained.** The 95/100 target is not established. The next
verification step requires a pre-provisioned Python 3.12 environment with `.[dev]` installed (or
working package-index access), followed by the exact CI checks and a valid GitHub Actions credential
if remote CI is required.
